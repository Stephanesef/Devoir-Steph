-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : dim. 06 mars 2022 à 18:22
-- Version du serveur : 5.7.33
-- Version de PHP : 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `digital_university`
--

-- --------------------------------------------------------

--
-- Structure de la table `classe`
--

CREATE TABLE `classe` (
  `id` bigint(20) NOT NULL,
  `nomclasse` varchar(255) NOT NULL,
  `idfiliere` int(11) NOT NULL,
  `idpromotion` int(11) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `classe`
--

INSERT INTO `classe` (`id`, `nomclasse`, `idfiliere`, `idpromotion`, `created_at`, `updated_at`) VALUES
(1, 'IG1', 4, 1, '2022-03-06 19:40:09', '2022-03-06 19:40:09');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `filiere`
--

CREATE TABLE `filiere` (
  `id` bigint(20) NOT NULL,
  `nomFiliere` varchar(255) NOT NULL,
  `descriptionFiliere` text NOT NULL,
  `IdUniversity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `filiere`
--

INSERT INTO `filiere` (`id`, `nomFiliere`, `descriptionFiliere`, `IdUniversity`, `created_at`, `updated_at`) VALUES
(1, 'Comptabilité et Audit', 'Nous formons des experts internationaux en comptabilité', 3, '2022-03-06 18:25:56', '2022-03-06 18:25:56'),
(2, 'Administration des Affaires', 'Nous mettons à la disposition du marché de cadres compétents', 3, '2022-03-06 18:27:00', '2022-03-06 18:27:00'),
(3, 'Management des Ressources humaines', 'Des cadres compétents pour gérer les ressources humaines', 3, '2022-03-06 18:28:27', '2022-03-06 18:28:27'),
(4, 'Informatique de Gestion', 'Nous formons des analyste programmeurs chevronnés', 2, '2022-03-06 18:31:09', '2022-03-06 18:31:09'),
(5, 'Commerce International', 'Biens, services et capitaux faisant l\'objet d\'un échange entre au moins deux pays', 2, '2022-03-06 18:32:03', '2022-03-06 18:32:03'),
(6, 'Transport et Logistique', 'Nous formons des experts dans le domaine du transport', 2, '2022-03-06 18:39:16', '2022-03-06 18:39:16'),
(7, 'Analyse Biomédicales et Biochimiques', 'Nous mettons à disposition du marché des experts du laboratoire', 1, '2022-03-06 18:43:28', '2022-03-06 18:43:28'),
(8, 'Système Informatique et Logiciel', 'Des experts des nouvelles technologies', 1, '2022-03-06 18:44:16', '2022-03-06 18:44:16'),
(9, 'Finances Comptabilité et Audit', 'Nous vous garantissons des experts internationaux', 1, '2022-03-06 18:45:07', '2022-03-06 18:45:07'),
(10, 'Génie Electrique et Energies renouvelables', 'Venez découvrir les merveilles de l\'institut', 1, '2022-03-06 18:45:56', '2022-03-06 18:45:56'),
(11, 'Télécommunication et Réseaux Informatiques', 'Des experts en télécommunication et réseaux', 4, '2022-03-06 18:50:15', '2022-03-06 18:50:15'),
(12, 'Action Commerciale et Force de Vente', 'Nous nous engageons à faire de vous des experts en stratégie commerciale', 4, '2022-03-06 18:50:55', '2022-03-06 18:50:55'),
(13, 'Informatique de Gestion', 'La programmation n\'aura plus de secrets pour vous', 4, '2022-03-06 18:51:28', '2022-03-06 18:51:28'),
(14, 'Génie Logiciel', 'Applique les principes et techniques d\' ingénierie à la conception de systèmes logiciels', 5, '2022-03-06 19:20:42', '2022-03-06 19:20:42'),
(15, 'Sécurité Informatique', 'Expert en sécurité des systèmes', 5, '2022-03-06 19:21:45', '2022-03-06 19:21:45'),
(16, 'Internet et Multimédia', 'Le secteur des technologies de l’information suscite beaucoup d’intérêts et de nouveaux métiers arrivent sur le marché de l’emploi', 5, '2022-03-06 19:23:14', '2022-03-06 19:23:14');

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(10, '2014_10_12_000000_create_users_table', 1),
(11, '2014_10_12_100000_create_password_resets_table', 1),
(12, '2019_08_19_000000_create_failed_jobs_table', 1),
(13, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(14, '2022_02_22_003746_create_university_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `promotion`
--

CREATE TABLE `promotion` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nomPromotion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rangPromotion` int(11) NOT NULL,
  `IdUniversity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `promotion`
--

INSERT INTO `promotion` (`id`, `nomPromotion`, `rangPromotion`, `IdUniversity`, `created_at`, `updated_at`) VALUES
(1, '1ère Année', 1, '2', '2022-03-05 16:47:30', '2022-03-05 16:47:30'),
(2, '2ème Année', 2, '2', '2022-03-05 16:49:07', '2022-03-05 16:49:07'),
(3, '3ème Année', 3, '2', '2022-03-05 16:49:17', '2022-03-05 16:49:17'),
(4, '1ère Année', 1, '3', '2022-03-06 18:22:07', '2022-03-06 18:22:07'),
(5, '1ère Année', 1, '1', '2022-03-06 18:42:09', '2022-03-06 18:42:09'),
(6, '2ème Année', 2, '1', '2022-03-06 18:42:14', '2022-03-06 18:42:14'),
(7, '3ème Année', 3, '1', '2022-03-06 18:42:20', '2022-03-06 18:42:20'),
(8, 'Master 1', 4, '1', '2022-03-06 18:42:29', '2022-03-06 18:42:29'),
(9, 'Master 2', 5, '1', '2022-03-06 18:42:35', '2022-03-06 18:42:35'),
(10, '1ère Année', 1, '4', '2022-03-06 18:49:26', '2022-03-06 18:49:26'),
(11, '2ème Année', 2, '4', '2022-03-06 18:49:33', '2022-03-06 18:49:33'),
(12, '3ème Année', 3, '4', '2022-03-06 18:49:41', '2022-03-06 18:49:41'),
(13, '1ère Année', 1, '5', '2022-03-06 19:19:06', '2022-03-06 19:19:06'),
(14, '2ème Année', 2, '5', '2022-03-06 19:19:12', '2022-03-06 19:19:12'),
(15, '3ème Année', 3, '5', '2022-03-06 19:19:17', '2022-03-06 19:19:17');

-- --------------------------------------------------------

--
-- Structure de la table `university`
--

CREATE TABLE `university` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nomUniversite` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emailUniversite` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `AnneeInscription` int(11) NOT NULL,
  `NumAutorisation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `university`
--

INSERT INTO `university` (`id`, `nomUniversite`, `emailUniversite`, `AnneeInscription`, `NumAutorisation`, `Description`, `file_path`, `created_at`, `updated_at`) VALUES
(1, 'Institut Supérieur le Faucon (ESF)  ', 'faucon@gmail.com', 2001, 'AUT N°870SG/MESP/877ER', 'Nous sommes l’une des meilleures universités de Technologie et de Management du Bénin\r\nNous ne faisons pas que donner aux étudiants une formation et des expériences qui les préparent au succès dans leur carrière. Nous les aidons à réussir dans leur carrière, à découvrir un domaine qui les passionne et à être les meilleurs.', 'Pg6VnY6UvB9Vdw3azNwB66sJEtFMB3OsD7oNydCD.jpg', NULL, '2022-03-06 20:30:38'),
(2, 'Haute Ecole de Commerce et de Management', 'levihaoudou@gmail.com', 2002, 'N°25487/21/SG/MESP', 'Depuis plus de 20 ans, la Haute Ecole de Commerce et de Management (HECM) implantée sur plusieurs sites à travers le Bénin, est l\'une des meilleures écoles de commerce et de management de la sous-région. Le dynamisme de toute son équipe, ses ambitions et son leadership en témoignent surtout à travers ses résultats annuels et ses nombreux prix.\n\nEn appui à la modalité de formation classique du face à face, cette plateforme de cours à distance avec des services d’accompagnement en ligne et/ou en présentiel est implémentée pour interconnecter les étudiants de ses 7 campus (Jéricho, Akpakpa, Atrokpocodji, Calavi, Porto-Novo, Bohicon et Parakou). Les étudiants peuvent désormais avec leurs terminaux mobiles sous iOS et Androïd (smartphone, tablette, iphone, ipad, windows phone, Pc…) accéder en dehors des amphis et salles de cours, aux cours et leurs contenus (ressources diverses, évaluations, tests, bibliothèque numérique, base de données, travaux collaboratifs …) depuis n’importe où et à tout moment. Ils peuvent également interagir avec tous les autres acteurs du dispositif de formation (pairs étudiants, enseignants, corps enseignant, administration…).\n\nNous assurons ainsi la continuité pédagogique dans nos parcours quel que soit le contexte et prévoyons d\'ouvrir de nouvelles perspectives pour les futurs usagers de notre plateforme en dehors de nos étudiants des parcours traditionnels.\n\nSur ce, je nous souhaite de très grandes et belles choses sur cet espace dématérialisé de transmission de connaissance qui ne fait que confirmer notre place d\'Ecole Leader.', '5qMdRKr1TW56m85eXQiEtvdoKDiPdMNSXXIHk4i2.jpg', '2022-03-05 15:14:00', '2022-03-05 16:47:15'),
(3, 'Institut Supérieur des Métiers de l\'Audio Visuel', 'geniushl26@gmail.com', 1998, 'N°784/SG/87/MSP/ER/877', 'L’Institut Supérieur de Management Adonaï (ISM Adonaï) est une école supérieure de formation aux métiers de management, d’audit, de comptabilité et de finance. Il est reconnu par l’Etat béninois pour délivrer les diplômes universitaires de Licence (BAC+3) et de Master (BAC+5) en administration des affaires privées et publiques.\r\n\r\n-Il met à votre disposition l’une des infrastructures scolaires ultramodernes, sise au cœur de la ville de Cotonou (quartier Saint Jean, von derrière Golfe Télévision), construite et dédiée à la formation supérieure professionnelle et comprenant :\r\n-des matériels didactiques,\r\n-des équipements informatiques de pointe,\r\n-une salle multimédia avec connexion internet haut débit,\r\n-un parking de véhicules au sous-sol,\r\n-une infirmerie,\r\n-des salles de cours climatisées etc…\r\n\r\nLes programmes permettent de répondre aux besoins de compétence exprimés par les entreprises grâce à notre partenariat école entreprise inauguré en septembre 2005 sous l’égide de l’Agence Nationale Pour l’Emploi (ANPE).', 'CEbgfCBIqGV3GFvQ2hseKP2f6lAfYK9ajGb3qnMg.jpg', '2022-03-05 15:15:11', '2022-03-06 18:21:47'),
(4, 'Université Catholique de l\'Afrique de l\'Ouest', 'stephsefande@gmail.com', 2005, 'AUT N°87/SG/MSP/2004', 'L’Université Catholique de l’Afrique de l’Ouest (UCAO) est le plus grand réseau universitaire privé décentralisé d’Afrique, avec des implantations d’Unités au Bénin, au Burkina Faso, en Côte d’Ivoire, en Guinée, au Mali, au Sénégal et au Togo. Son siège international est à Ouagadougou, où le Rectorat jouit d’un accord de siège avec l’État du Burkina Faso.\r\nL’UCAO est membre du Conseil Africain et Malgache de l’Enseignement Supérieur (CAMES) qui reconnait ses diplômes, de l’Association des Universités et Instituts Catholique', 'xfbjseZaq9uIaxUKj5RGwye4q507cK3D6ERgQfbe.jpg', '2022-03-05 15:17:08', '2022-03-06 19:11:56'),
(5, 'Institut de Formation et de Recherche en Informatique', 'jjacquessef@yahoo.fr', 1998, 'N°05/97/SG/PR', 'La vocation de l\'Institut de Formation et de Recherche en Informatique (IFRI) de l\'Université d\'Abomey-Calavi est de former des apprenants capables de devenir des acteurs de solutions informatiques aux différents problèmes de société en s\'appuyant sur les récents développements des Technologies de l\'Information et de la Communication. Les performances des étudiants de l\'IFRI font parler de l\'Institut au plan national qu\'international. Les multiples distinctions enregistrées au fil des années sont très illustratives. Championne en 2014 puis en 2016 au concours national de programmation, l\'équipe de l\'IFRI a occupé la deuxième place en 2015. Sur plus de cent (100) équipes sélectionnées de plusieurs pays de la sous-région participant au concours organisé par la société MAPCOM, l\'équipe de l\'IFRI a fini 5ème . Troisième au concours Innovaton organisé par la fondation HOUNGBEDJI en 2017, elle a gagné la totalité des 4 bourses d’études en Chine offertes par la même fondation en 2018.', 'QotQPzY5PA8VdywP0gP03O3drbigcScJFagbHQGR.jpg', '2022-03-05 15:19:30', '2022-03-06 19:18:58'),
(6, 'SuperAdmin', 'admin@gmail.com', 2015, '555', 'administrateur', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `classe`
--
ALTER TABLE `classe`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `filiere`
--
ALTER TABLE `filiere`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `promotion`
--
ALTER TABLE `promotion`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `university`
--
ALTER TABLE `university`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `classe`
--
ALTER TABLE `classe`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `filiere`
--
ALTER TABLE `filiere`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `promotion`
--
ALTER TABLE `promotion`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `university`
--
ALTER TABLE `university`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
