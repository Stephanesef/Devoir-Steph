@extends('layout_admin')
@section('content')
    <div class="container">
        <div class="row">
        <div class="col-lg-3">
        </div>
        <div class="col-lg-6">
        @if (isset($msg))
            @if($msg="success")
            <div class="alert alert-info alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Super !</strong> Université enregistrée.
                </div>
            @endif
        @endif

        <div class="row card text-white bg-dark">
            <h2 class="card-header">Enregistrement des Universités</h2>
            <div class="card-body">
                <form action="{{ route('university@save') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <input type="email" class="form-control  @error('emailUniversite') is-invalid @enderror" name="emailUniversite" id="emailUniversite" placeholder="Identifiant (email)" value="{{ old('email') }}">
                        @error('emailUniversite')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <textarea class="form-control  @error('nomUniversite') is-invalid @enderror" name="nomUniversite" id="nomUniversite" placeholder="Nom de l'Université">{{ old('nom') }}</textarea>
                        @error('nomUniversite')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <textarea class="form-control  @error('AnneeInscription') is-invalid @enderror" name="AnneeInscription" id="AnneeInscription" placeholder="Année de création">{{ old('annee') }}</textarea>
                        @error('AnneeInscription')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <textarea class="form-control  @error('NumAutorisation') is-invalid @enderror" name="NumAutorisation" id="autorisation" placeholder="Numéro Autorisation">{{ old('autorisation') }}</textarea>
                        @error('NumAutorisation')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-info">Enregistrer </button>
                </form>     
            </div>
        </div>
        </div>
        </div>
    </div>
    @endsection