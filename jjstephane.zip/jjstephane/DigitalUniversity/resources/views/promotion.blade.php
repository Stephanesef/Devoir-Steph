@extends('layout_admin')

@section('content')
    <div class="container">
        <div class="row">
        <div class="col-lg-3">
        </div>
        <div class="col-lg-6">
        @if (isset($msg))
            @if($msg="success")
            <div class="alert alert-info alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Super !</strong> Promotion enregistrée.
                </div>
            @endif
        @endif
        <div class="row card text-white bg-dark">
            <h2 class="card-header">Paramétrages des Promotions</h2>
            <div class="card-body">
                <form action="{{ route('promotion@save') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <input class="form-control  @error('nomPromotion') is-invalid @enderror" name="nomPromotion" id="nomPromotion" placeholder="Nom de la promotion">
                        @error('nomPromotion')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <input class="form-control  @error('rangPromotion') is-invalid @enderror" name="rangPromotion" id="rangPromotion" placeholder="Rang de la promotion">
                        @error('rangPromotion')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <input type="hidden" class="form-control  @error('IdUniversity') is-invalid @enderror" name="IdUniversity" value="{{$session}}" id="IdUniversity" placeholder="Rang de la promotion">
                        @error('iduniversity')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-info">Enregistrer </button>
                </form>     
            </div>
        </div>
        </div>
        </div>
    </div>
    @endsection

