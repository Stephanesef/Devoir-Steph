@extends('layout_admin')

@section('content')
    <div class="container">
        <div class="row">
        <div class="col-lg-3">
        </div>
        <div class="col-lg-6">
        @if (isset($msg))
            @if($msg="success")
            <div class="alert alert-info alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Super !</strong> Classe enregistrée.
                </div>
            @endif
        @endif
        <div class="row card text-white bg-dark">
            <h2 class="card-header">Paramétrages des Classes</h2>
            <div class="card-body">
                <form action="{{ route('classe@save') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <input class="form-control  @error('nomclasse') is-invalid @enderror" name="nomclasse" id="nomclasse" placeholder="Nom de la classe">
                        @error('nomclasse')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                    <label for="cars">Choisir la Promotion:</label>
                        <select class="form-control  @error('idpromotion') is-invalid @enderror" name="idpromotion" id="idpromotion">
                                <option disabled selected value="-">Promotion</option>
                                @foreach($promotionlist as $promotion) 
                                    <option value="{{$promotion->id}}">{{$promotion->nomPromotion}}</option>
                                @endforeach
                        </select>
                        @error('idpromotion')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                    <label for="cars">Choisir la Filière:</label>
                        <select class="form-control  @error('idfiliere') is-invalid @enderror" name="idfiliere" id="idfiliere">
                                <option disabled selected value="-">Filière</option>
                                @foreach($filierelist as $filiere) 
                                    <option value="{{$filiere->id}}">{{$filiere->nomFiliere}}</option>
                                @endforeach
                        </select>
                        @error('idfiliere')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    
                    <button type="submit" class="btn btn-info">Enregistrer </button>
                </form>     
            </div>
        </div>
        </div>
        </div>
    </div>
    @endsection