@extends('layout_admin')
@section('content')
    <div class="container">
        <div class="row">
        <div class="col-lg-3">
        </div>
        <div class="col-lg-6">
        @if (isset($msg))
            @if($msg="success")
            <div class="alert alert-info alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Super !</strong> Informations actualisées.
                </div>
            @endif
        @endif

        <div class="row card text-white bg-dark">
            <h2 class="card-header">Paramétrage</h2>
            <div class="card-body">
                <form action="{{ route('university@update') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                    <label for="cars">Description de l'établissement:</label>
                        <textarea type="text" class="form-control  @error('Description') is-invalid @enderror" name="Description" id="Description" placeholder="Parlez un peu de votre établissement"></textarea>
                        @error('Description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                    <label for="cars">Veillez choisir une image descriptive de l'établissement:</label>
                        <input type="file" class="form-control  @error('file_path') is-invalid @enderror" name="file_path" id="file_path">
                        @error('file_path')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-info">Enregistrer </button>
                </form>     
            </div>
        </div>
        </div>
        </div>
    </div>
    @endsection