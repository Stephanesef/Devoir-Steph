<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="homepage/css/style1.css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="/">Administration Digital University</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/homeadmin">Home</a></li>
      @if($session==6)
      <li><a href="university">Université</a></li>
      @else
      <li><a href="update">Paramétrage</a></li>
      <li><a href="promotion">Promotion</a></li>
      <li><a href="filiere">Filière</a></li>
      <li><a href="classe">Classe</a></li>
      @endif
      <!--<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Page 1-1</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li>-->
      
    </ul>
    <!--<ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>-->
  </div>
</nav>
  
<div class="container">
<div class="row">
<div class="col-lg-6">

</div>
<div class="col-lg-6" id="msg-welcome">
@if (isset($nometablissement))
      Bonjour {{$nometablissement}}
      @endif
</div>
</div>
@yield('content')
</div>

</body>
</html>
