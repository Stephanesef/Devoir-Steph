@extends('layout_admin')
@section('content')
    <div class="container">
        <div class="row">
        <div class="col-lg-3">
        </div>
        <div class="col-lg-6">
        @if (isset($msg))
            @if($msg="success")
            <div class="alert alert-info alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Super !</strong> Informations actualisées.
                </div>
            @endif
        @endif

        <div class="row card text-white bg-dark">
            <div class="row">
                <div class="col-lg-12" id="titelwelcomeadmin">
                    Administration Digital University
                </div>
            </div>
        </div>
        </div>
        </div>
    </div>
    @endsection