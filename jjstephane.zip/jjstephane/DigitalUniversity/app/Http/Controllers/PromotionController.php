<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
session_start();
class PromotionController extends Controller
{
    //
   
    public function create()
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        return view('promotion')
        ->with('nometablissement',$var)
        ->with('session',$_SESSION['id']);
    }
    
    public function save(Request $request)
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        $this->validate($request ,[
            'nomPromotion'=>'bail|required|max:100',
            'rangPromotion'=>'bail|required|integer',
            'IdUniversity'=>'bail|required|integer'
        ]);

        $promotion=new \App\Models\Promotion;
        $promotion->nomPromotion=$request->nomPromotion;
        $promotion->rangPromotion=$request->rangPromotion;
        $promotion->IdUniversity=$request->IdUniversity;
        $promotion->save();

        return view('promotion')
        ->with('nometablissement',$var)
        ->with('msg','success')
        ->with('session',$_SESSION['id']);
    }
}
