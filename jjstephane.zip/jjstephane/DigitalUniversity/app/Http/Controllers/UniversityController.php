<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Models\University;
session_start();
class UniversityController extends Controller
{
    //

    public function connexion(Request $request)
    {
        $this->validate($request ,[
            'emailUniversite'=>'bail|exists:university,emailUniversite|required|email',
            'pass'=>'bail|required|max:100'
        ]);
        $universityquery=DB::table('university')
        ->where('emailUniversite', '=',$request->emailUniversite)->get();  
            foreach($universityquery as $unv)
            {
                    $_SESSION['id']=$unv->id;
            }
            return view('welcomeadmin')
            ->with('session',$_SESSION['id']);
    }

    public function createadmin()
    {
            return view('welcomeadmin')
            ->with('session',$_SESSION['id']);
    }

    public function create()
    {
        return view('university')
                ->with('session',$_SESSION['id']);
    }

    public function save(Request $request)
    {
        $this->validate($request ,[
            'emailUniversite'=>'bail|unique:university|required|email',
            'nomUniversite'=>'bail|required|max:100',
            'AnneeInscription'=>'bail|required|integer',
            'NumAutorisation'=>'bail|required|max:500'
        ]);

        $university=new \App\Models\University;
        $university->emailUniversite=$request->emailUniversite;
        $university->nomUniversite=$request->nomUniversite;
        $university->AnneeInscription=$request->AnneeInscription;
        $university->NumAutorisation=$request->NumAutorisation;
        $university->Description="vide";
        $university->save();

        return view('university')
                ->with('session',$_SESSION['id'])
                ->with('msg','success');
    }

    public function createupdate()
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        return view('admin')
                ->with('nometablissement',$var)
                ->with('session',$_SESSION['id']);
    }

    public function update(Request $request)
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        $this->validate($request ,[
            'Description'=>'bail|required|max:2000',
            'file_path'=>'bail|required|max:500'
        ]);
        if ($request->hasFile('file_path')) {

            $this->validate($request ,[
                'image' => 'mimes:jpeg,bmp,png' // Only allow .jpg, .bmp and .png file types.
            ]);

            // Save the file locally in the storage/public/ folder under a new folder named /product
            //$request->file->store('product', 'public');
            $request->file('file_path')->store('images');

            // Store the record, using the new file hashname which will be it's new filename identity.
           // $university=new \App\Models\University;
            $university = University::find($_SESSION['id']);
            $university->Description=$request->Description;
            $university->file_path=$request->file('file_path')->hashName();
            $university->update();
        }
       

        return view('admin')
        ->with('nometablissement',$var)
                ->with('session',$_SESSION['id'])
                ->with('msg','success');
    }
}
