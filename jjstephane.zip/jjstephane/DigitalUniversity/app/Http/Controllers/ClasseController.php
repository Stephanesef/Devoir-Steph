<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
session_start();
class ClasseController extends Controller
{
    //
    public function create()
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        $promotionquery=DB::table('promotion')->where('IdUniversity', '=',$_SESSION['id'])->get();   
        $filierequery=DB::table('filiere')->where('IdUniversity',$_SESSION['id'])->get();
     

        return view('classe')
        ->with('session',$_SESSION['id'])
        ->with('nometablissement',$var)
        ->with('promotionlist',$promotionquery)
       ->with('filierelist',$filierequery);
    }
    public function save(Request $request)
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        $this->validate($request ,[
            'nomclasse'=>'bail|required|max:100',
            'idfiliere'=>'bail|required|integer',
            'idpromotion'=>'bail|required|integer'
        ]);

        $classe=new \App\Models\Classe;
        $classe->nomclasse=$request->nomclasse;
        $classe->idfiliere=$request->idfiliere;
        $classe->idpromotion=$request->idpromotion;
        $classe->save();

        $promotionquery=DB::table('promotion')->where('IdUniversity', '=',$_SESSION['id'])->get();   
        $filierequery=DB::table('filiere')->where('IdUniversity',$_SESSION['id'])->get();
        return view('classe')
        ->with('msg','success')
        ->with('session',$_SESSION['id'])
        ->with('nometablissement',$var)
        ->with('promotionlist',$promotionquery)
        ->with('filierelist',$filierequery);
    }
}