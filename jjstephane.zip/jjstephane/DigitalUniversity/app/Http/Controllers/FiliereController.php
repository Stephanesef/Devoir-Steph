<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
session_start();

class FiliereController extends Controller
{
    //
    
    public function create()
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        return view('filiere')
        ->with('nometablissement',$var)
        ->with('session',$_SESSION['id']);
    }
    public function save(Request $request)
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$_SESSION['id'])->get();
        foreach($universityquery as $unv)
        {
               $var=$unv->nomUniversite;
        }
        $this->validate($request ,[
            'nomFiliere'=>'bail|required|max:100',
            'IdUniversity'=>'bail|required|integer',
            'descriptionFiliere'=>'bail|required|max:1000',
        ]);

        $promotion=new \App\Models\Filiere;
        $promotion->nomFiliere=$request->nomFiliere;
        $promotion->descriptionFiliere=$request->descriptionFiliere;
        $promotion->IdUniversity=$request->IdUniversity;
        $promotion->save();

        return view('filiere')
        ->with('nometablissement',$var)
        ->with('msg','success')
        ->with('session',$_SESSION['id']);
    }
}
