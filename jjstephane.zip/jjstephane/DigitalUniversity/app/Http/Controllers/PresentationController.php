<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class PresentationController extends Controller
{
    //
    
    public function create($id)
    {
        $universityquery=DB::table('university')
        ->where('id', '=',$id)->get();
        foreach($universityquery as $unv)
        {
               $var=$unv;
        }

        $filierequery=DB::table('filiere')
        ->where('IdUniversity','=',$id)->get();
        
        return view('presentationuniversity')
        ->with('universitylist',$var)
        ->with('filierelist',$filierequery);
        }
}
