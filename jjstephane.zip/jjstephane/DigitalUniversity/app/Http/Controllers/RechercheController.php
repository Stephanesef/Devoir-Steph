<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class RechercheController extends Controller
{
    //
    public function create()
    {
        $universityquery=DB::table('university')->get();

        return view('recherche')
        ->with('universitylist',$universityquery);
    }
}
