<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('homepage');
});

Route::get('/services', function () {
    return view('services');
});

Route::get('/recherche','rechercheController@create')->name('recherche@create');

Route::get('/presentation/{id}','presentationController@create')->name('presentation@create');
/*   Administratrion   */

Route::get('homeadmin','UniversityController@createadmin')->name('university@createadmin');
Route::get('university','UniversityController@create')->name('university@create');
Route::post('university','UniversityController@save')->name('university@save');
Route::get('update','UniversityController@createupdate')->name('university@createupdate');
Route::post('update','UniversityController@update')->name('university@update');
Route::post('connexion','UniversityController@connexion')->name('university@connexion');
Route::get('promotion','PromotionController@create')->name('promotion@create');
Route::post('promotion','PromotionController@save')->name('promotion@save');
Route::get('filiere','FiliereController@create')->name('filiere@create');
Route::post('filiere','FiliereController@save')->name('filiere@save');
Route::get('classe','ClasseController@create')->name('classe@create');
Route::post('classe','ClasseController@save')->name('classe@save');


