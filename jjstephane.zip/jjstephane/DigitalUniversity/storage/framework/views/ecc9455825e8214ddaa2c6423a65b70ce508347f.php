<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="homepage/css/reset.css" />
    <link rel="stylesheet" href="homepage/css/style.css" />
    <link rel="stylesheet" href="homepage/css/grid_12.css" />
    <link rel="stylesheet" href="homepage/css/slider.css" />
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Condiment' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="homepage/js/jquery.js"></script>
    <script type="text/javascript" src="homepage/js/jquery-1.7.min.js"></script>
    <script type="text/javascript" src="homepage/js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="homepage/js/tms-0.4.x.js"></script>
    <script>
        $(document).ready(function(){
            $('.slider')._TMS({
                show:0,
                pauseOnHover:true,
                prevBu:false,
                nextBu:false,
                playBu:false,
                duration:1000,
                preset:'fade',
                pagination:true,
                pagNums:false,
                slideshow:7000,
                numStatus:true,
                banners:'fromRight',
                waitBannerAnimation:false,
                progressBar:false
            })
        });
    </script>
    <!--[if lt IE 8]>
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
            <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
    </div>
    <![endif]-->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="homepage/js/html5.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="homepage/css/ie.css">
    <![endif]-->
</head>
<body>
<div class="main">
    <!--==============================header=================================-->
    <header>
        <h1><a href="index.html"><img src="homepage/images/digital.png" alt=""></a></h1>
        
        <div class="clear"></div>
        <nav class="box-shadow">
            <div>
                <ul class="menu">
                    <li class="home-page current"><a href="/"><span></span></a></li>
                    <li><a href="#">Nos Services</a></li>
                    <li><a href="recherche">Sélection</a></li>
                    <li><a href="#" >Nous Contacter</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#myModal">Connexion</a></li>
                </ul>
                <div class="social-icons">
                    <span>Nous Suivre:</span>
                    <a href="#" class="icon-3"></a>
                    <a href="#" class="icon-2"></a>
                    <a href="#" class="icon-1"></a>
                </div>
                <div class="clear"></div>
            </div>
        </nav>
    </header>
    <!--==============================content================================-->
    <section id="content">
    <div class="container">
        <div class="row" id="mainrowrechercher">
            <div class="col-lg-12">
                <div class="row">
                    <?php $__currentLoopData = $universitylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($university->id !==6 ): ?>
                    <div class="col-lg-4" id="grpselection">
                        <div class="card" style="width: 18rem;">
                            <img class="card-img-top" src="<?php echo e(asset('storage/app/' . $university->file_path)); ?>" alt="Card image cap">
                            <div class="card-body">
                                <p class="card-text"><a id="nameuniversityrecherche" href="presentation/<?php echo e($university->id); ?>"><?php echo e($university->nomUniversite); ?></a></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Connexion à Digital University</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form action="<?php echo e(route('university@connexion')); ?>" method="POST">
          <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="email">Identifiant:</label>
                        <input type="email" class="form-control  <?php $__errorArgs = ['emailUniversite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="emailUniversite" id="emailUniversite" placeholder="Entrer votre identifiant" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['emailUniversite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                    <label for="pwd">Mot de Pass:</label>
                        <input type="password" class="form-control  <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pass" id="pass" placeholder="Enter votre mot de pass" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['emailUniversite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            
            <button type="submit" class="btn btn-primary">Se Connecter</button>
        </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Fermer</button>
        </div>
        
      </div>
</div>
<!--==============================footer=================================-->
<footer>
    <p>© 2012 Global</p>
    <p>Website template by <a href="http://store.templatemonster.com?aff=netsib1" target="_blank" rel="nofollow">www.templatemonster.com</a></p>
</footer>
</body>
</html><?php /**PATH D:\WEB\WorkShop\digital_university\DigitalUniversity\resources\views/recherche.blade.php ENDPATH**/ ?>