
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
        <div class="col-lg-3">
        </div>
        <div class="col-lg-6">
        <?php if(isset($msg)): ?>
            <?php if($msg="success"): ?>
            <div class="alert alert-info alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Super !</strong> Informations actualisées.
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="row card text-white bg-dark">
            <div class="row">
                <div class="col-lg-12" id="titelwelcomeadmin">
                    Administration Digital University
                </div>
            </div>
        </div>
        </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\WorkShop\digital_university\DigitalUniversity\resources\views/welcomeadmin.blade.php ENDPATH**/ ?>