<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="homepage/css/reset.css" />
    <link rel="stylesheet" href="homepage/css/style.css" />
    <link rel="stylesheet" href="homepage/css/grid_12.css" />
    <link rel="stylesheet" href="homepage/css/slider.css" />
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Condiment' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="homepage/js/jquery.js"></script>
    <script type="text/javascript" src="homepage/js/jquery-1.7.min.js"></script>
    <script type="text/javascript" src="homepage/js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="homepage/js/tms-0.4.x.js"></script>
    <script>
        $(document).ready(function(){
            $('.slider')._TMS({
                show:0,
                pauseOnHover:true,
                prevBu:false,
                nextBu:false,
                playBu:false,
                duration:1000,
                preset:'fade',
                pagination:true,
                pagNums:false,
                slideshow:7000,
                numStatus:true,
                banners:'fromRight',
                waitBannerAnimation:false,
                progressBar:false
            })
        });
    </script>
    <!--[if lt IE 8]>
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
            <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
    </div>
    <![endif]-->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="homepage/js/html5.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="homepage/css/ie.css">
    <![endif]-->
</head>
<body>
<div class="main">
    <!--==============================header=================================-->
    <header>
        <h1><a href="index.html"><img src="homepage/images/logo.png" alt=""></a></h1>
        
        <div class="clear"></div>
        <nav class="box-shadow">
            <div>
                <ul class="menu">
                    <li class="home-page current"><a href=" "><span></span></a></li>
                    <li><a href="services">Nos Services</a></li>
                    <li><a href="about.html">Universités</a></li>
                    <li><a href="clients.html">Sélection</a></li>
                    <li><a href="clients.html" >Nous Contacter</a></li>
                    <li><a href="clients.html" data-toggle="modal" data-target="#myModal">Connexion</a></li>
                </ul>
                <div class="social-icons">
                    <span>Nous Suivre:</span>
                    <a href="#" class="icon-3"></a>
                    <a href="#" class="icon-2"></a>
                    <a href="#" class="icon-1"></a>
                </div>
                <div class="clear"></div>
            </div>
        </nav>
    </header>
    <!--==============================content================================-->
    
    <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Connexion à Digital University</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form action="/action_page.php">
  <div class="form-group">
    <label for="email">Identifiant:</label>
    <input type="email" class="form-control" placeholder="Entrer votre identifiant" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Mot de Pass:</label>
    <input type="password" class="form-control" placeholder="Enter votre mot de pass" id="pwd">
  </div>
  
  <button type="submit" class="btn btn-primary">Se Connecter</button>
</form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Fermer</button>
        </div>
        
      </div>
    </div>
  </div>
</div>
<!--==============================footer=================================-->
<footer>
    <p>© 2012 Global</p>
    <p>Website template by <a href="http://store.templatemonster.com?aff=netsib1" target="_blank" rel="nofollow">www.templatemonster.com</a></p>
</footer>
</body>
</html>
<?php /**PATH D:\Lab\Web\digital_university\DigitalUniversity\resources\views/services.blade.php ENDPATH**/ ?>